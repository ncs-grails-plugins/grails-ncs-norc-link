package edu.umn.ncs

class PersonLink {

	// this is the person being linked to.
	Person person

	// This links to the NORC SU_ID
	String norcSuId

    static constraints = {
    }
}
