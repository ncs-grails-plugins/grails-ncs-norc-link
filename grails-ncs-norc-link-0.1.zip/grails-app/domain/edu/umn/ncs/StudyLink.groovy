package edu.umn.ncs

class StudyLink {
	// This class links a study to external IDs
	Study study

	// This links the study to a NORC project ID
	String NorcProjectId

    static constraints = {
    }
}
