package edu.umn.ncs

class InstrumentLink {
	// This is the instrument the IDs link to
	Instrument instrument
	
	// this is the NORC DOC_ID
	String NorcDocId

    static constraints = {
    }
}
